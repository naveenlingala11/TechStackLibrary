package com.project.TechStackLibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechStackLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
