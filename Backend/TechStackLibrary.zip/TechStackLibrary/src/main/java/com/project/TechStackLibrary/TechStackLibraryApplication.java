package com.project.TechStackLibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechStackLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechStackLibraryApplication.class, args);
	}

}
